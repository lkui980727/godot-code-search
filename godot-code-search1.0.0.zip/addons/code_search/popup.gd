@tool
extends Panel

# 从插件传递的 EditorInterface 实例
var editor_interface: EditorInterface
var plugin_ref: Object

# 节点引用（类型为 TextEdit）
@onready var collapsed_button: Button = $CollapsedButton
@onready var expanded_panel: VBoxContainer = $ExpandedPanel
@onready var search_line: TextEdit = $ExpandedPanel/SearchRow/LineEdit
@onready var confirm_btn: Button = $ExpandedPanel/SearchRow/ConfirmButton
@onready var prev_match_btn: Button = $ExpandedPanel/SearchRow/PrevMatchButton
@onready var next_match_btn: Button = $ExpandedPanel/SearchRow/NextMatchButton
@onready var match_count_label: Label = $ExpandedPanel/SearchRow/MatchCountLabel
@onready var color_picker_btn: ColorPickerButton = $ExpandedPanel/SearchRow/ColorPickerButton
@onready var case_sensitive_btn: Button = $ExpandedPanel/SearchRow/CaseSensitiveButton
@onready var regex_btn: Button = $ExpandedPanel/SearchRow/RegexButton
@onready var history_btn: MenuButton = $ExpandedPanel/SearchRow/HistoryButton
@onready var clear_btn: Button = $ExpandedPanel/SearchRow/ClearButton
@onready var close_btn: Button = $ExpandedPanel/SearchRow/CloseButton
@onready var replace_line: TextEdit = $ExpandedPanel/ReplaceRow/ReplaceLineEdit
@onready var replace_label: Label = $ExpandedPanel/ReplaceRow/ReplaceLabel
@onready var range_option: OptionButton = $ExpandedPanel/ReplaceRow/RangeOption
@onready var replace_all_btn: Button = $ExpandedPanel/ReplaceRow/ReplaceAllButton
@onready var confirm_dialog: ConfirmationDialog = $ConfirmDialog

# 状态变量
var is_expanded: bool = false
var highlight_color: Color = Color.BLUE
var marked_lines: Array[int] = []
var current_match_index: int = -1
var regex_error: bool = false
var all_matches: Array[Dictionary] = []

# 拖拽相关
var dragging: bool = false
var drag_offset: Vector2 = Vector2()

# 去抖计时器
var debounce_timer: Timer

signal popup_closed

const MAX_HISTORY = 10
var pending_replace_data = {}

func _get_text(key: String) -> String:
	if plugin_ref and plugin_ref.has_method("get_text"):
		return plugin_ref.get_text(key)
	return key

func _ready():
	collapsed_button.visible = true
	expanded_panel.visible = false
	match_count_label.text = ""

	_set_children_mouse_filter_pass(self)

	debounce_timer = Timer.new()
	debounce_timer.one_shot = true
	debounce_timer.timeout.connect(_update_search_highlight)
	add_child(debounce_timer)

	_setup_ui_texts()

	# 连接信号
	collapsed_button.pressed.connect(_on_collapsed_button_pressed)
	confirm_btn.pressed.connect(_on_confirm_pressed)
	prev_match_btn.pressed.connect(_on_prev_match_pressed)
	next_match_btn.pressed.connect(_on_next_match_pressed)
	close_btn.pressed.connect(_on_close_pressed)
	search_line.text_changed.connect(_on_search_text_changed)
	color_picker_btn.color_changed.connect(_on_color_changed)
	case_sensitive_btn.toggled.connect(_on_search_option_changed)
	regex_btn.toggled.connect(_on_search_option_changed)
	replace_all_btn.pressed.connect(_on_replace_all_pressed)
	clear_btn.pressed.connect(_on_clear_pressed)
	range_option.item_selected.connect(_on_range_item_selected)

	history_btn.about_to_popup.connect(_on_history_menu_about_to_popup)
	history_btn.get_popup().id_pressed.connect(_on_history_item_selected)

	# 范围选项
	range_option.clear()
	range_option.add_item(_get_text("RANGE_CURRENT"), 0)
	range_option.add_item(_get_text("RANGE_OPEN"), 1)
	range_option.add_item(_get_text("RANGE_PROJECT"), 2)

	confirm_dialog.confirmed.connect(_on_replace_confirmed)
	confirm_dialog.ok_button_text = _get_text("CONFIRM")
	confirm_dialog.cancel_button_text = _get_text("CANCEL")

	load_ui_state()

func _setup_ui_texts():
	confirm_btn.text = _get_text("CONFIRM")
	prev_match_btn.text = _get_text("PREV")
	next_match_btn.text = _get_text("NEXT")
	clear_btn.text = _get_text("CLEAR")
	history_btn.text = _get_text("HISTORY")
	replace_all_btn.text = _get_text("REPLACE_ALL")
	replace_label.text = _get_text("REPLACE_WITH")
	close_btn.text = "X"

func refresh_ui():
	_setup_ui_texts()
	if range_option and range_option.get_item_count() >= 3:
		range_option.set_item_text(0, _get_text("RANGE_CURRENT"))
		range_option.set_item_text(1, _get_text("RANGE_OPEN"))
		range_option.set_item_text(2, _get_text("RANGE_PROJECT"))
	confirm_dialog.ok_button_text = _get_text("CONFIRM")
	confirm_dialog.cancel_button_text = _get_text("CANCEL")
	load_search_history()
	if not search_line.text.is_empty():
		var editor = get_current_code_edit()
		if editor:
			_update_search_highlight()
		else:
			clear_highlight()
			if match_count_label: match_count_label.text = ""
	else:
		clear_highlight()
		if match_count_label: match_count_label.text = ""
	queue_redraw()

func _set_children_mouse_filter_pass(node: Node):
	for child in node.get_children():
		if child is Control:
			child.mouse_filter = Control.MOUSE_FILTER_PASS
			_set_children_mouse_filter_pass(child)

# ---------- 展开折叠 ----------
func reset_to_collapsed():
	if is_expanded:
		toggle_expand()
	else:
		collapsed_button.visible = true
		expanded_panel.visible = false

func toggle_expand():
	is_expanded = !is_expanded
	collapsed_button.visible = !is_expanded
	expanded_panel.visible = is_expanded
	if is_expanded:
		search_line.grab_focus()

func _on_collapsed_button_pressed():
	toggle_expand()

func _on_close_pressed():
	clear_highlight()
	popup_closed.emit()

# ---------- 颜色 ----------
func _on_color_changed(color: Color):
	highlight_color = color
	_update_search_highlight()

# ---------- 确认 ----------
func _on_confirm_pressed():
	add_to_history(search_line.text)
	jump_to_first_match()

# ---------- 搜索文本变化 ----------
func _on_search_text_changed():
	debounce_timer.start(0.05)

func _on_search_option_changed(_toggled: bool):
	_update_search_highlight()

func _on_clear_pressed():
	clear_history()
	search_line.text = ""
	replace_line.text = ""   # 同时清空替换框
	debounce_timer.stop()
	_update_search_highlight()

func _on_range_item_selected(index: int):
	save_range_setting(index)
	_update_search_highlight()

# ---------- 导航 ----------
func _on_prev_match_pressed():
	if all_matches.is_empty() or current_match_index < 0:
		return
	current_match_index = (current_match_index - 1 + all_matches.size()) % all_matches.size()
	jump_to_match_index(current_match_index)

func _on_next_match_pressed():
	if all_matches.is_empty() or current_match_index < 0:
		return
	current_match_index = (current_match_index + 1) % all_matches.size()
	jump_to_match_index(current_match_index)

func jump_to_match_index(index: int):
	if index < 0 or index >= all_matches.size():
		return
	var match_data = all_matches[index]
	var editor = match_data.editor
	var start_line = match_data.start_line   # 使用 start_line
	if not editor:
		return

	var se = editor_interface.get_script_editor()
	var current_editor = get_current_code_edit()
	if editor != current_editor:
		for script_editor in se.get_open_scripts():
			var code_edit = _get_code_edit_from_script_editor(script_editor)
			if code_edit == editor:
				se.set_current_editor(script_editor)
				break
	editor.set_caret_line(start_line)
	editor.set_caret_column(0)
	editor.center_viewport_to_caret()
	update_match_count()

func jump_to_first_match():
	if all_matches.is_empty():
		return
	current_match_index = 0
	jump_to_match_index(0)

# ---------- 搜索高亮核心 ----------
func _update_search_highlight():
	regex_error = false
	var text = search_line.text
	if text.is_empty():
		clear_highlight()
		return

	clear_all_highlights()

	var pattern: String
	var case_flag = "" if case_sensitive_btn.button_pressed else "(?i)"
	if regex_btn.button_pressed:
		pattern = case_flag + text
	else:
		pattern = case_flag + _escape_regexp(text)

	var regex = RegEx.new()
	if regex.compile(pattern) != OK:
		regex_error = true
		match_count_label.text = _get_text("INVALID_REGEX")
		return

	var current_editor = get_current_code_edit()
	if not current_editor:
		return

	var full_text = current_editor.text
	all_matches.clear()
	var matches = _get_matches_in_text(full_text, regex)
	for match in matches:
		all_matches.append({ "editor": current_editor, "start_line": match.start_line, "end_line": match.end_line })
		# 高亮所有匹配行
		for line in range(match.start_line, match.end_line + 1):
			marked_lines.append(line)
			current_editor.set_line_background_color(line, highlight_color)
	current_editor.queue_redraw()

	if all_matches.is_empty():
		current_match_index = -1
	else:
		current_match_index = 0
		jump_to_first_match()

	update_match_count()

func clear_all_highlights():
	var current_editor = get_current_code_edit()
	if current_editor:
		for line in marked_lines:
			current_editor.set_line_background_color(line, Color.TRANSPARENT)
		current_editor.queue_redraw()
	marked_lines.clear()
	all_matches.clear()

func clear_highlight(code_edit = null):
	clear_all_highlights()
	current_match_index = -1
	regex_error = false

# ---------- 辅助函数 ----------
func _get_matches_in_text(full_text: String, regex: RegEx) -> Array:
	var matches = []
	var reg_match = regex.search(full_text)
	while reg_match:
		var start_line = full_text.count("\n", 0, reg_match.get_start())
		var end_line = full_text.count("\n", 0, reg_match.get_end())
		matches.append({ "start_line": start_line, "end_line": end_line })
		reg_match = regex.search(full_text, reg_match.get_end())
	return matches

# ---------- 工具函数 ----------
func get_current_code_edit():
	if not editor_interface:
		return null
	var se = editor_interface.get_script_editor()
	var current_editor = se.get_current_editor()
	if not current_editor:
		return null
	return _get_code_edit_from_script_editor(current_editor)

func _get_code_edit_from_script_editor(script_editor) -> CodeEdit:
	if script_editor.has_method("get_text_edit"):
		return script_editor.get_text_edit()
	elif script_editor.has_method("get_base_editor"):
		return script_editor.get_base_editor()
	elif script_editor.has_method("get_code_edit"):
		return script_editor.get_code_edit()
	else:
		for child in script_editor.get_children():
			if child is CodeEdit:
				return child
	return null

func _get_script_name(editor: CodeEdit) -> String:
	var se = editor_interface.get_script_editor()
	for script_editor in se.get_open_scripts():
		var code_edit = _get_code_edit_from_script_editor(script_editor)
		if code_edit == editor:
			return script_editor.get_script_path().get_file()
	return "未知"

static func _escape_regexp(text: String) -> String:
	var escaped = ""
	for c in text:
		if c in [".", "?", "*", "+", "^", "$", "|", "(", ")", "[", "]", "{", "}", "\\"]:
			escaped += "\\" + c
		else:
			escaped += c
	return escaped

# ---------- 计数更新 ----------
func update_match_count():
	if regex_error:
		return
	var total = all_matches.size()
	if total == 0:
		match_count_label.text = ""
	else:
		if current_match_index >= 0:
			match_count_label.text = _get_text("MATCH_COUNT").format({"current": current_match_index + 1, "total": total})
		else:
			match_count_label.text = _get_text("MATCH_COUNT_SIMPLE").format({"total": total})

# ---------- 搜索历史 ----------
func load_search_history():
	if not editor_interface:
		return
	var settings = editor_interface.get_editor_settings()
	var raw_history = settings.get_setting("code_search/search_history")
	var history_items = []
	if typeof(raw_history) == TYPE_ARRAY:
		history_items = raw_history
	elif typeof(raw_history) == TYPE_PACKED_STRING_ARRAY:
		var old = raw_history as PackedStringArray
		history_items = []
		for s in old:
			history_items.append({ "text": s, "time": Time.get_unix_time_from_system() })
	else:
		history_items = []

	history_items.sort_custom(func(a,b): return a.time > b.time)

	var popup = history_btn.get_popup()
	popup.clear()
	if history_items.is_empty():
		popup.add_item(_get_text("EMPTY_HISTORY"), -1)
		popup.set_item_disabled(0, true)
	else:
		for i in range(min(history_items.size(), MAX_HISTORY)):
			var item = history_items[i]
			popup.add_item(item.text, i)

func add_to_history(text: String):
	if text.is_empty() or not editor_interface:
		return
	var settings = editor_interface.get_editor_settings()
	var history = settings.get_setting("code_search/search_history")
	if history == null:
		history = []

	var history_items = []
	if typeof(history) == TYPE_ARRAY:
		history_items = history
	elif typeof(history) == TYPE_PACKED_STRING_ARRAY:
		var old = history as PackedStringArray
		history_items = []
		for s in old:
			history_items.append({ "text": s, "time": Time.get_unix_time_from_system() })

	var found = false
	for i in range(history_items.size()):
		if history_items[i].text == text:
			history_items[i].time = Time.get_unix_time_from_system()
			found = true
			break
	if not found:
		history_items.append({ "text": text, "time": Time.get_unix_time_from_system() })

	history_items.sort_custom(func(a,b): return a.time > b.time)
	if history_items.size() > MAX_HISTORY:
		history_items.resize(MAX_HISTORY)

	settings.set_setting("code_search/search_history", history_items)

func clear_history():
	if not editor_interface:
		return
	var settings = editor_interface.get_editor_settings()
	settings.set_setting("code_search/search_history", [])
	load_search_history()

func _on_history_menu_about_to_popup():
	load_search_history()

func _on_history_item_selected(id: int):
	var popup = history_btn.get_popup()
	var text = popup.get_item_text(id)
	if text != _get_text("EMPTY_HISTORY"):
		search_line.text = text
		_on_search_text_changed()

# ---------- 范围设置保存/加载 ----------
func save_range_setting(index: int):
	if not editor_interface:
		return
	var settings = editor_interface.get_editor_settings()
	settings.set_setting("code_search/popup_range", index)

func load_range_setting() -> int:
	if not editor_interface:
		return 0
	var settings = editor_interface.get_editor_settings()
	if settings.has_setting("code_search/popup_range"):
		return settings.get_setting("code_search/popup_range")
	return 0

func load_ui_state():
	load_search_history()
	var range_idx = load_range_setting()
	range_option.selected = range_idx

# ---------- 替换功能 ----------
func _on_replace_all_pressed():
	var search_text = search_line.text
	var replace_text = replace_line.text
	if search_text.is_empty():
		return

	var total_matches = all_matches.size()
	if total_matches == 0:
		return

	var range_name = [_get_text("RANGE_CURRENT"), _get_text("RANGE_OPEN"), _get_text("RANGE_PROJECT")][range_option.selected]
	confirm_dialog.dialog_text = _get_text("CONFIRM_REPLACE").format({"range": range_name, "count": total_matches})

	pending_replace_data = {
		"search_text": search_text,
		"replace_text": replace_text,
		"regex": regex_btn.button_pressed,
		"case_sensitive": case_sensitive_btn.button_pressed,
		"range": range_option.selected
	}

	confirm_dialog.popup_centered()

func _on_replace_confirmed():
	var data = pending_replace_data
	if data.is_empty():
		return

	var search_text = data.search_text
	var replace_text = data.replace_text
	var use_regex = data.regex
	var case_sensitive = data.case_sensitive
	var range_type = data.range

	var pattern: String
	var case_flag = "" if case_sensitive else "(?i)"
	if use_regex:
		pattern = case_flag + search_text
	else:
		pattern = case_flag + _escape_regexp(search_text)

	var regex = RegEx.new()
	if regex.compile(pattern) != OK:
		return

	var current_editor = get_current_code_edit()
	if not current_editor:
		return

	if range_type == 0:  # 当前文件
		var full_text = current_editor.text
		var new_text = regex.sub(full_text, replace_text, true)
		if new_text != full_text:
			current_editor.text = new_text
	else:  # 所有打开文件（弹窗仅支持当前文件，但保留扩展）
		# 简单起见，仅替换当前文件
		var full_text = current_editor.text
		var new_text = regex.sub(full_text, replace_text, true)
		if new_text != full_text:
			current_editor.text = new_text

	_update_search_highlight()
	add_to_history(search_text)

# ---------- 拖拽实现 ----------
func _gui_input(event):
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			if not _is_mouse_over_interactive_control():
				dragging = true
				drag_offset = get_global_mouse_position() - global_position
				accept_event()
		else:
			dragging = false
	elif event is InputEventMouseMotion and dragging:
		global_position = get_global_mouse_position() - drag_offset
		accept_event()

func _is_mouse_over_interactive_control() -> bool:
	var local_pos = get_local_mouse_position()
	var target = _find_control_at_point(self, local_pos)
	return target != null and _is_interactive(target)

func _find_control_at_point(parent: Control, point: Vector2) -> Control:
	for child in parent.get_children():
		if not (child is Control) or not child.visible:
			continue
		var rect = Rect2(child.position, child.size)
		if rect.has_point(point):
			var deeper = _find_control_at_point(child, point - child.position)
			return deeper if deeper else child
	return null

func _is_interactive(control: Control) -> bool:
	return (control is Button or
			control is LineEdit or
			control is TextEdit or
			control is CheckButton or
			control is OptionButton or
			control is ColorPickerButton or
			control is MenuButton)
