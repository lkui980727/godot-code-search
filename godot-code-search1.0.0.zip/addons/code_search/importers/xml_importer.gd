extends Object

static func can_parse(text: String) -> bool:
	return text.strip_edges().begins_with("<?xml")

static func parse(text: String) -> Node:
	# 简单返回根节点
	var root = Node2D.new()
	root.name = "XMLRoot"
	return root
