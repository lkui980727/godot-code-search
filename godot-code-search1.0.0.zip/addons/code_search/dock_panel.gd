@tool
extends VBoxContainer

# 自定义正则转义函数
static func _escape_regexp(text: String) -> String:
	var escaped = ""
	for c in text:
		if c in [".", "?", "*", "+", "^", "$", "|", "(", ")", "[", "]", "{", "}", "\\"]:
			escaped += "\\" + c
		else:
			escaped += c
	return escaped

var editor_interface: EditorInterface
var plugin_ref: Object

# 节点引用
@onready var search_edit: TextEdit = $SearchRow/SearchLine
@onready var color_picker: ColorPickerButton = $SearchRow/ColorPicker
@onready var history_btn: MenuButton = $SearchRow/HistoryButton
@onready var clear_btn: Button = $SearchRow/ClearButton
@onready var case_sensitive_btn: Button = $OptionRow/CaseSensitive
@onready var regex_btn: Button = $OptionRow/Regex
@onready var range_option: OptionButton = $OptionRow/RangeOption
@onready var match_count_label: Label = $OptionRow/MatchCountLabel
@onready var prev_btn: Button = $NavRow/PrevButton
@onready var next_btn: Button = $NavRow/NextButton
@onready var goto_selected_btn: Button = $NavRow/GotoSelectedButton
@onready var replace_edit: TextEdit = $ReplaceRow/ReplaceLine
@onready var replace_label: Label = $ReplaceRow/ReplaceLabel
@onready var replace_all_btn: Button = $ReplaceRow/ReplaceAllButton
@onready var batch_copy_path_btn: Button = $BatchRow/BatchCopyPathButton
@onready var batch_goto_btn: Button = $BatchRow/BatchGotoButton
@onready var export_btn: Button = $BatchRow/ExportButton
@onready var import_scene_btn: Button = $BatchRow/ImportSceneButton
@onready var result_tree: Tree = $ResultTree
@onready var confirm_dialog: ConfirmationDialog = $ConfirmDialog
@onready var regex_error_label: Label = $SearchRow/RegexErrorLabel
@onready var context_menu: PopupMenu = $ContextMenu
@onready var preview_dialog: AcceptDialog = $PreviewDialog
@onready var preview_text: RichTextLabel = $PreviewDialog/PreviewText
@onready var status_label: Label = $StatusLabel if has_node("StatusLabel") else null

# 文件类型行
@onready var file_type_row: HBoxContainer = $FileTypeRow if has_node("FileTypeRow") else null
@onready var file_type_label: Label = $FileTypeRow/FileTypeLabel if has_node("FileTypeRow/FileTypeLabel") else null
@onready var file_type_option: OptionButton = $FileTypeRow/FileTypeOption if has_node("FileTypeRow/FileTypeOption") else null

# 状态变量
var highlight_color: Color = Color.BLUE
var editor_highlights: Dictionary = {}          # 存储每个编辑器中高亮的行号列表
var current_match_index: int = -1
var regex_error: bool = false
var all_matches: Array[Dictionary] = []         # 每个元素: { editor, start_line, end_line, file, text }

var search_cache: Dictionary = {}
var debounce_timer: Timer
var pending_replace_data: Dictionary = {}

var context_item: TreeItem = null

const MAX_HISTORY = 20

# 右键菜单项ID
const MENU_COPY_LINE = 1
const MENU_COPY_PATH = 2
const MENU_SHOW_IN_FOLDER = 3
const MENU_PREVIEW = 4

# ---------- 翻译辅助 ----------
func _get_text(key: String) -> String:
	if plugin_ref and plugin_ref.has_method("get_text"):
		return plugin_ref.get_text(key)
	return key

# ---------- 应用编辑器主题与布局 ----------
func _apply_editor_theme():
	if not editor_interface:
		return
	var base_control = editor_interface.get_base_control()
	if not base_control:
		return
	var editor_theme = base_control.theme
	if not editor_theme:
		return

	var font_color = editor_theme.get_color("font_color", "Editor")
	var selection_color = editor_theme.get_color("selection_color", "Editor")
	var accent_color = editor_theme.get_color("accent_color", "Editor")
	var disabled_color = editor_theme.get_color("disabled_font_color", "Editor")

	var buttons = [prev_btn, next_btn, goto_selected_btn, batch_copy_path_btn, batch_goto_btn, export_btn, import_scene_btn, clear_btn, replace_all_btn]
	for btn in buttons:
		if not btn: continue
		btn.add_theme_color_override("font_color", font_color)
		btn.add_theme_color_override("font_hover_color", accent_color)
		btn.add_theme_color_override("font_pressed_color", accent_color)
		btn.add_theme_color_override("font_disabled_color", disabled_color)

	if history_btn:
		history_btn.add_theme_color_override("font_color", font_color)
		history_btn.add_theme_color_override("font_hover_color", accent_color)
		history_btn.add_theme_color_override("font_pressed_color", accent_color)

	if search_edit:
		search_edit.add_theme_color_override("font_color", font_color)
		search_edit.add_theme_color_override("selection_color", selection_color)
	if replace_edit:
		replace_edit.add_theme_color_override("font_color", font_color)
		replace_edit.add_theme_color_override("selection_color", selection_color)

	for lbl in [match_count_label, replace_label, regex_error_label, file_type_label, status_label]:
		if lbl: lbl.add_theme_color_override("font_color", font_color)

	if range_option:
		range_option.add_theme_color_override("font_color", font_color)
	if file_type_option:
		file_type_option.add_theme_color_override("font_color", font_color)

	if result_tree:
		result_tree.add_theme_color_override("font_color", font_color)
		result_tree.add_theme_color_override("selection_color", selection_color)

	if color_picker:
		color_picker.add_theme_color_override("font_color", font_color)

	if context_menu:
		context_menu.add_theme_color_override("font_color", font_color)
		context_menu.add_theme_color_override("selection_color", selection_color)

	add_theme_constant_override("separation", 4)
	for container in [search_edit.get_parent(), $OptionRow, $NavRow, $ReplaceRow, $BatchRow, file_type_row]:
		if container and container is HBoxContainer:
			container.add_theme_constant_override("separation", 4)
	if result_tree:
		result_tree.add_theme_constant_override("item_margin", 2)
		result_tree.add_theme_constant_override("line_separation", 2)

# ---------- 初始化 ----------
func _ready():
	range_option.clear()
	range_option.add_item(_get_text("RANGE_CURRENT"), 0)
	range_option.add_item(_get_text("RANGE_OPEN"), 1)
	range_option.add_item(_get_text("RANGE_PROJECT"), 2)

	if file_type_label:
		file_type_label.text = _get_text("FILE_TYPE_LABEL")
	if file_type_option:
		file_type_option.clear()
		file_type_option.add_item(_get_text("FILE_TYPE_GD_ONLY"), 0)
		file_type_option.add_item(_get_text("FILE_TYPE_INCLUDE_RESOURCES"), 1)
		file_type_option.add_item(_get_text("FILE_TYPE_ALL_TEXT"), 2)
		load_file_type_setting()

	debounce_timer = Timer.new()
	debounce_timer.one_shot = true
	debounce_timer.timeout.connect(_search)
	add_child(debounce_timer)

	search_edit.text_changed.connect(_on_search_text_changed)
	color_picker.color_changed.connect(_on_color_changed)
	case_sensitive_btn.toggled.connect(_on_option_changed)
	regex_btn.toggled.connect(_on_option_changed)
	range_option.item_selected.connect(_on_option_changed)
	if file_type_option:
		file_type_option.item_selected.connect(_on_file_type_changed)
	prev_btn.pressed.connect(_on_prev_pressed)
	next_btn.pressed.connect(_on_next_pressed)
	goto_selected_btn.pressed.connect(_on_goto_selected_pressed)
	batch_copy_path_btn.pressed.connect(_on_batch_copy_path_pressed)
	batch_goto_btn.pressed.connect(_on_batch_goto_pressed)
	export_btn.pressed.connect(_on_export_pressed)
	import_scene_btn.pressed.connect(_on_import_scene_pressed)
	clear_btn.pressed.connect(_on_clear_pressed)
	replace_all_btn.pressed.connect(_on_replace_all_pressed)
	result_tree.item_selected.connect(_on_result_tree_item_selected)
	result_tree.gui_input.connect(_on_result_tree_gui_input)
	result_tree.item_activated.connect(_on_result_tree_item_activated)

	history_btn.about_to_popup.connect(_on_history_menu_about_to_popup)
	history_btn.get_popup().id_pressed.connect(_on_history_item_selected)

	confirm_dialog.confirmed.connect(_on_replace_confirmed)

	result_tree.hide_root = true
	result_tree.select_mode = Tree.SELECT_MULTI
	result_tree.columns = 1

	context_menu.add_item(_get_text("COPY_LINE"), MENU_COPY_LINE)
	context_menu.add_item(_get_text("COPY_PATH"), MENU_COPY_PATH)
	context_menu.add_item(_get_text("SHOW_IN_FOLDER"), MENU_SHOW_IN_FOLDER)
	context_menu.add_item(_get_text("PREVIEW"), MENU_PREVIEW)
	context_menu.id_pressed.connect(_on_context_menu_id_pressed)

	load_ui_state()
	_refresh_ui_texts()
	_apply_editor_theme()

# ---------- UI 刷新 ----------
func _refresh_ui_texts():
	if prev_btn: prev_btn.text = _get_text("PREV")
	if next_btn: next_btn.text = _get_text("NEXT")
	if clear_btn: clear_btn.text = _get_text("CLEAR")
	if history_btn: history_btn.text = _get_text("HISTORY")
	if replace_all_btn: replace_all_btn.text = _get_text("REPLACE_ALL")
	if replace_label: replace_label.text = _get_text("REPLACE_WITH")
	if goto_selected_btn: goto_selected_btn.text = _get_text("GOTO_SELECTED")
	if batch_copy_path_btn: batch_copy_path_btn.text = _get_text("BATCH_COPY_PATH")
	if batch_goto_btn: batch_goto_btn.text = _get_text("BATCH_GOTO")
	if export_btn: export_btn.text = _get_text("EXPORT")
	if import_scene_btn: import_scene_btn.text = _get_text("IMPORT_SCENE")
	if range_option and range_option.get_item_count() >= 3:
		range_option.set_item_text(0, _get_text("RANGE_CURRENT"))
		range_option.set_item_text(1, _get_text("RANGE_OPEN"))
		range_option.set_item_text(2, _get_text("RANGE_PROJECT"))
	if file_type_label:
		file_type_label.text = _get_text("FILE_TYPE_LABEL")
	if file_type_option and file_type_option.get_item_count() >= 3:
		file_type_option.set_item_text(0, _get_text("FILE_TYPE_GD_ONLY"))
		file_type_option.set_item_text(1, _get_text("FILE_TYPE_INCLUDE_RESOURCES"))
		file_type_option.set_item_text(2, _get_text("FILE_TYPE_ALL_TEXT"))
	if confirm_dialog:
		confirm_dialog.ok_button_text = _get_text("CONFIRM")
		confirm_dialog.cancel_button_text = _get_text("CANCEL")
	var idx = context_menu.get_item_index(MENU_COPY_LINE)
	if idx != -1:
		context_menu.set_item_text(idx, _get_text("COPY_LINE"))
	idx = context_menu.get_item_index(MENU_COPY_PATH)
	if idx != -1:
		context_menu.set_item_text(idx, _get_text("COPY_PATH"))
	idx = context_menu.get_item_index(MENU_SHOW_IN_FOLDER)
	if idx != -1:
		context_menu.set_item_text(idx, _get_text("SHOW_IN_FOLDER"))
	idx = context_menu.get_item_index(MENU_PREVIEW)
	if idx != -1:
		context_menu.set_item_text(idx, _get_text("PREVIEW"))

func refresh_ui():
	_refresh_ui_texts()
	load_search_history()
	if file_type_option:
		load_file_type_setting()
	_apply_editor_theme()
	if not search_edit.text.is_empty():
		var editor = _get_current_code_edit()
		if editor:
			_search()
		else:
			result_tree.clear()
			if match_count_label: match_count_label.text = ""
			_clear_all_highlights()
	else:
		result_tree.clear()
		if match_count_label: match_count_label.text = ""
		_clear_all_highlights()
	queue_redraw()
	update_minimum_size()

# ---------- 事件处理 ----------
func _on_search_text_changed():
	debounce_timer.start(0.05)

func _on_color_changed(color: Color):
	highlight_color = color
	_search()

func _on_option_changed(_val = null):
	_search()

func _on_file_type_changed(index: int):
	save_file_type_setting(index)
	_search()

func _on_prev_pressed():
	if all_matches.is_empty(): return
	var new_index = (current_match_index - 1 + all_matches.size()) % all_matches.size()
	_jump_to_match_index(new_index)

func _on_next_pressed():
	if all_matches.is_empty(): return
	var new_index = (current_match_index + 1) % all_matches.size()
	_jump_to_match_index(new_index)

func _on_goto_selected_pressed():
	var selected = result_tree.get_selected()
	if not selected: return
	var metadata = selected.get_metadata(0)
	if metadata is Dictionary and metadata.has("start_line"):
		_jump_to_match_by_metadata(metadata)

func _on_clear_pressed():
	clear_history()
	search_edit.text = ""
	replace_edit.text = ""
	debounce_timer.stop()
	_search()

# ---------- 批量操作 ----------
func _on_batch_copy_path_pressed():
	var selected_items = _get_selected_items()
	var paths: Array[String] = []
	for item in selected_items:
		var metadata = item.get_metadata(0)
		if not metadata is Dictionary:
			continue
		var file_path: String = ""
		if metadata.has("type") and metadata.type == "file":
			file_path = metadata.get("path", "")
		else:
			if metadata.has("editor") and metadata.editor:
				file_path = _get_script_path(metadata.editor)
			elif metadata.has("file"):
				file_path = metadata.file
		if not file_path.is_empty() and not paths.has(file_path):
			paths.append(file_path)
	if paths.is_empty():
		return
	var text = "\n".join(paths)
	DisplayServer.clipboard_set(text)
	print("已复制 %d 个文件路径" % paths.size())

func _on_batch_goto_pressed():
	var selected_items = _get_selected_items()
	var matches: Array[Dictionary] = []
	for item in selected_items:
		var metadata = item.get_metadata(0)
		if metadata is Dictionary and metadata.has("start_line"):
			matches.append(metadata)
	if matches.is_empty():
		return
	var msg = _get_text("BATCH_GOTO_CONFIRM").format({"count": matches.size()})
	confirm_dialog.dialog_text = msg
	confirm_dialog.ok_button_text = _get_text("CONFIRM")
	confirm_dialog.cancel_button_text = _get_text("CANCEL")
	pending_replace_data = {
		"batch_goto": true,
		"matches": matches,
		"index": 0
	}
	confirm_dialog.popup_centered()

# ---------- 导出 ----------
func _on_export_pressed():
	if all_matches.is_empty():
		print("没有可导出的结果")
		return
	var file_dialog = FileDialog.new()
	file_dialog.access = FileDialog.ACCESS_FILESYSTEM
	file_dialog.file_mode = FileDialog.FILE_MODE_SAVE_FILE
	file_dialog.title = _get_text("EXPORT_TITLE")
	file_dialog.add_filter("*.txt", "Text Files")
	file_dialog.add_filter("*", "All Files")
	file_dialog.file_selected.connect(_on_export_file_selected)
	add_child(file_dialog)
	file_dialog.popup_centered()

func _on_export_file_selected(path: String):
	var content = _generate_export_content()
	var file = FileAccess.open(path, FileAccess.WRITE)
	if file:
		file.store_string(content)
		file.close()
		print("导出成功: ", path)
	else:
		print("导出失败: 无法写入文件")

func _generate_export_content() -> String:
	var lines: Array[String] = []
	lines.append("Code Search Results")
	lines.append("Generated: " + Time.get_datetime_string_from_system())
	lines.append("Search Text: " + search_edit.text)
	lines.append("Case Sensitive: " + str(case_sensitive_btn.button_pressed))
	lines.append("Regex: " + str(regex_btn.button_pressed))
	lines.append("Range: " + [_get_text("RANGE_CURRENT"), _get_text("RANGE_OPEN"), _get_text("RANGE_PROJECT")][range_option.selected])
	lines.append("Total Matches: " + str(all_matches.size()))
	lines.append("")
	var file_map: Dictionary = {}
	for match in all_matches:
		var file_path: String
		var start_line: int
		var end_line: int
		if match.has("editor") and match.editor:
			file_path = _get_script_path(match.editor)
			start_line = match.start_line + 1
			end_line = match.end_line + 1
		else:
			file_path = match.file
			start_line = match.start_line + 1
			end_line = match.end_line + 1
		if not file_map.has(file_path):
			file_map[file_path] = []
		file_map[file_path].append({"start": start_line, "end": end_line})
	for file_path in file_map.keys():
		lines.append("File: " + file_path)
		for item in file_map[file_path]:
			lines.append("  Lines %d-%d" % [item.start, item.end])
		lines.append("")
	return "\n".join(lines)

# 递归获取所有选中的 TreeItem
func _get_selected_items() -> Array[TreeItem]:
	var selected: Array[TreeItem] = []
	var root = result_tree.get_root()
	if not root: return selected
	var stack: Array[TreeItem] = [root]
	while not stack.is_empty():
		var current = stack.pop_back()
		if current.is_selected(0):
			selected.append(current)
		var child = current.get_first_child()
		while child:
			stack.append(child)
			child = child.get_next()
	return selected

# ---------- 右键菜单 ----------
func _on_result_tree_gui_input(event: InputEvent):
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_RIGHT and event.pressed:
		var item = result_tree.get_item_at_position(event.position)
		if item:
			context_item = item
			var metadata = item.get_metadata(0)
			var is_file_node = metadata is Dictionary and metadata.has("type") and metadata.type == "file"
			context_menu.set_item_disabled(context_menu.get_item_index(MENU_COPY_LINE), is_file_node)
			context_menu.set_item_disabled(context_menu.get_item_index(MENU_COPY_PATH), false)
			context_menu.set_item_disabled(context_menu.get_item_index(MENU_SHOW_IN_FOLDER), false)
			context_menu.set_item_disabled(context_menu.get_item_index(MENU_PREVIEW), is_file_node)
			context_menu.popup_on_parent(Rect2(get_global_mouse_position(), Vector2()))

func _on_context_menu_id_pressed(id: int):
	if not context_item:
		return
	var metadata = context_item.get_metadata(0)
	if not metadata is Dictionary:
		return

	var is_file_node = metadata.has("type") and metadata.type == "file"
	var file_path: String = ""
	var line_text: String = ""

	if is_file_node:
		file_path = metadata.get("path", "")
	else:
		if metadata.has("start_line"):
			if metadata.has("editor") and metadata.editor:
				var lines = metadata.editor.text.split("\n")
				var start = metadata.start_line
				var end = metadata.end_line
				if start == end:
					line_text = lines[start].strip_edges()
				else:
					line_text = lines[start].strip_edges() + " ..."
				file_path = _get_script_path(metadata.editor)
			elif metadata.has("file"):
				file_path = metadata.file
				line_text = metadata.get("text", "")

	match id:
		MENU_COPY_LINE:
			if not is_file_node and not line_text.is_empty():
				DisplayServer.clipboard_set(line_text)
		MENU_COPY_PATH:
			if not file_path.is_empty():
				DisplayServer.clipboard_set(file_path)
		MENU_SHOW_IN_FOLDER:
			if not file_path.is_empty():
				var abs_path = ProjectSettings.globalize_path(file_path)
				if abs_path.is_empty():
					abs_path = file_path
				var dir_path = abs_path.get_base_dir()
				OS.shell_show_in_file_manager(dir_path)
		MENU_PREVIEW:
			if not is_file_node and metadata.has("start_line"):
				_show_preview(metadata)

# ---------- 预览功能 ----------
func _on_result_tree_item_activated():
	var selected = result_tree.get_selected()
	if not selected: return
	var metadata = selected.get_metadata(0)
	if metadata is Dictionary and metadata.has("start_line"):
		_show_preview(metadata)

func _show_preview(match_data: Dictionary):
	var text = _get_context_text(match_data)
	if text.is_empty():
		return
	preview_dialog.title = _get_text("PREVIEW_TITLE")
	preview_text.text = text
	preview_dialog.popup_centered()

func _get_context_text(match_data: Dictionary) -> String:
	var editor = match_data.get("editor")
	var start_line = match_data.start_line
	var end_line = match_data.end_line
	var file = match_data.get("file")
	var context_lines = 2
	var lines: Array[String] = []

	if editor:
		var all_lines = editor.text.split("\n")
		var s = max(0, start_line - context_lines)
		var e = min(all_lines.size() - 1, end_line + context_lines)
		for i in range(s, e + 1):
			var prefix = "> " if i >= start_line and i <= end_line else "  "
			lines.append("%s%4d: %s" % [prefix, i+1, all_lines[i].strip_edges()])
	elif file:
		var file_access = FileAccess.open(file, FileAccess.READ)
		if file_access:
			var content = file_access.get_as_text()
			var all_lines = content.split("\n")
			var s = max(0, start_line - context_lines)
			var e = min(all_lines.size() - 1, end_line + context_lines)
			for i in range(s, e + 1):
				var prefix = "> " if i >= start_line and i <= end_line else "  "
				lines.append("%s%4d: %s" % [prefix, i+1, all_lines[i].strip_edges()])
			file_access.close()
		else:
			return _get_text("PREVIEW_ERROR")
	else:
		return _get_text("PREVIEW_ERROR")
	return "\n".join(lines)

# ---------- 核心搜索 ----------
func _search():
	if not editor_interface: return
	_clear_all_highlights()
	regex_error = false
	if regex_error_label: regex_error_label.text = ""
	var text = search_edit.text
	if text.is_empty():
		result_tree.clear()
		if match_count_label: match_count_label.text = ""
		all_matches.clear()
		current_match_index = -1
		return

	var pattern: String
	var case_flag = "" if case_sensitive_btn.button_pressed else "(?i)"
	if regex_btn.button_pressed:
		pattern = case_flag + text
	else:
		pattern = case_flag + _escape_regexp(text)

	var regex = RegEx.new()
	if regex.compile(pattern) != OK:
		regex_error = true
		if regex_error_label: regex_error_label.text = _get_text("INVALID_REGEX")
		return

	var cache_key = _get_cache_key(text)
	if search_cache.has(cache_key):
		all_matches = search_cache[cache_key].duplicate()
		_update_ui_from_cache()
		return

	result_tree.clear()
	all_matches.clear()

	var current_editor = _get_current_code_edit()
	var se = editor_interface.get_script_editor()

	if status_label:
		status_label.text = _get_text("SEARCHING")
		status_label.visible = true

	if range_option.selected == 0:  # 当前文件
		if current_editor:
			_search_in_editor_full(current_editor, regex, true)
	elif range_option.selected == 1:  # 所有打开文件
		for script_editor in se.get_open_scripts():
			if not is_instance_valid(script_editor):
				continue
			var code_edit = _get_code_edit_from_script_editor(script_editor)
			if code_edit:
				_search_in_editor_full(code_edit, regex, true)
	else:  # 整个项目
		var extensions: PackedStringArray = []
		if file_type_option:
			match file_type_option.selected:
				0:
					extensions = [".gd"]
				1:
					extensions = [".gd", ".tscn", ".tres", ".json", ".txt", ".cfg"]
				2:
					extensions = [".gd", ".tscn", ".tres", ".json", ".txt", ".cfg", ".md", ".csv", ".xml", ".yaml"]
		else:
			extensions = [".gd"]
		var files = _get_files_by_extensions("res://", extensions)
		for file in files:
			var content = FileAccess.get_file_as_string(file)
			var matches = _get_matches_in_text(content, regex)
			for match in matches:
				all_matches.append({
					"file": file,
					"start_line": match.start_line,
					"end_line": match.end_line,
					"editor": null
				})

	if status_label:
		status_label.visible = false

	_build_result_tree()

	if all_matches.is_empty():
		current_match_index = -1
		if match_count_label:
			match_count_label.text = "0 " + _get_text("MATCH_COUNT_SIMPLE").format({"total": 0})
	else:
		current_match_index = 0
		var first_item = _get_first_match_item()
		if first_item:
			first_item.select(0)
			_jump_to_match_by_metadata(first_item.get_metadata(0))
		if match_count_label:
			match_count_label.text = _get_text("MATCH_COUNT").format({"current": 1, "total": all_matches.size()})

	search_cache[cache_key] = all_matches.duplicate()

# ---------- 辅助函数 ----------
func _get_cache_key(text: String) -> String:
	var file_type_val = file_type_option.selected if file_type_option else 0
	return "%s_%s_%s_%d_%d" % [text, case_sensitive_btn.button_pressed, regex_btn.button_pressed, range_option.selected, file_type_val]

func _get_files_by_extensions(path: String, extensions: PackedStringArray) -> Array:
	var files = []
	var dir = DirAccess.open(path)
	if dir:
		dir.list_dir_begin()
		var file_name = dir.get_next()
		while file_name != "":
			if dir.current_is_dir():
				files += _get_files_by_extensions(path.path_join(file_name), extensions)
			else:
				for ext in extensions:
					if file_name.ends_with(ext):
						files.append(path.path_join(file_name))
						break
			file_name = dir.get_next()
	return files

func _search_in_editor_full(editor: CodeEdit, regex: RegEx, should_highlight: bool):
	var full_text = editor.text
	var matches = _get_matches_in_text(full_text, regex)
	for match in matches:
		all_matches.append({ "editor": editor, "start_line": match.start_line, "end_line": match.end_line })
		if should_highlight:
			if not editor_highlights.has(editor):
				editor_highlights[editor] = []
			for line in range(match.start_line, match.end_line + 1):
				if line not in editor_highlights[editor]:
					editor_highlights[editor].append(line)
				editor.set_line_background_color(line, highlight_color)
	editor.queue_redraw()

func _get_matches_in_text(full_text: String, regex: RegEx) -> Array:
	var matches = []
	var reg_match = regex.search(full_text)
	while reg_match:
		var start_line = full_text.count("\n", 0, reg_match.get_start())
		var end_line = full_text.count("\n", 0, reg_match.get_end())
		matches.append({ "start_line": start_line, "end_line": end_line })
		reg_match = regex.search(full_text, reg_match.get_end())
	return matches

# ---------- 构建树 ----------
func _build_result_tree():
	result_tree.clear()
	var root = result_tree.create_item()
	var file_nodes: Dictionary = {}

	for match in all_matches:
		var file_key: String
		var display_text: String
		var file_path: String
		if match.has("editor") and match.editor:
			var editor = match.editor
			file_path = _get_script_path(editor)
			file_key = file_path.get_file()
			var start = match.start_line + 1
			var end = match.end_line + 1
			var lines = editor.text.split("\n")
			var preview = lines[match.start_line].strip_edges()
			if start != end:
				preview += " ..."
			display_text = "%d-%d: %s" % [start, end, preview]
		else:
			file_path = match.file
			file_key = file_path.get_file()
			var start = match.start_line + 1
			var end = match.end_line + 1
			display_text = "%d-%d" % [start, end]

		var file_node: TreeItem
		if file_nodes.has(file_key):
			file_node = file_nodes[file_key]
		else:
			file_node = result_tree.create_item(root)
			file_node.set_text(0, file_key)
			file_node.set_metadata(0, { "type": "file", "file_key": file_key, "path": file_path })
			file_nodes[file_key] = file_node

		var item_node = result_tree.create_item(file_node)
		item_node.set_text(0, display_text)
		item_node.set_metadata(0, match)

	for file_node in file_nodes.values():
		file_node.collapsed = false

func _get_first_match_item() -> TreeItem:
	var root = result_tree.get_root()
	if not root: return null
	var file_node = root.get_first_child()
	while file_node:
		var item = file_node.get_first_child()
		if item:
			return item
		file_node = file_node.get_next()
	return null

func _update_ui_from_cache():
	result_tree.clear()
	_clear_all_highlights()
	_build_result_tree()
	for match in all_matches:
		var editor = match.get("editor")
		if editor and is_instance_valid(editor):
			if not editor_highlights.has(editor):
				editor_highlights[editor] = []
			for line in range(match.start_line, match.end_line + 1):
				if line not in editor_highlights[editor]:
					editor_highlights[editor].append(line)
				editor.set_line_background_color(line, highlight_color)
			editor.queue_redraw()
	if all_matches.size() > 0:
		current_match_index = 0
		var first_item = _get_first_match_item()
		if first_item:
			first_item.select(0)
		if match_count_label:
			match_count_label.text = _get_text("MATCH_COUNT").format({"current": 1, "total": all_matches.size()})
	else:
		if match_count_label:
			match_count_label.text = "0 " + _get_text("MATCH_COUNT_SIMPLE").format({"total": 0})

# ---------- 高亮清除 ----------
func _clear_all_highlights():
	for editor in editor_highlights.keys():
		if is_instance_valid(editor):
			for line in editor_highlights[editor]:
				editor.set_line_background_color(line, Color.TRANSPARENT)
			editor.queue_redraw()
	editor_highlights.clear()

# ---------- 跳转 ----------
func _jump_to_match_index(index: int):
	if index < 0 or index >= all_matches.size():
		return
	var match_data = all_matches[index]
	_jump_to_match_by_metadata(match_data)

func _jump_to_match_by_metadata(match_data: Dictionary):
	var editor = match_data.get("editor")
	var start_line = match_data.start_line
	var file = match_data.get("file")

	if editor:
		var se = editor_interface.get_script_editor()
		var current_editor = _get_current_code_edit()
		if editor != current_editor:
			for script_editor in se.get_open_scripts():
				if not is_instance_valid(script_editor):
					continue
				var code_edit = _get_code_edit_from_script_editor(script_editor)
				if code_edit == editor:
					se.set_current_editor(script_editor)
					break
		editor.set_caret_line(start_line)
		editor.set_caret_column(0)
		editor.center_viewport_to_caret()
	elif file != null and file is String and not file.is_empty():
		# 仅对脚本文件打开，避免非脚本文件弹窗
		if file.ends_with(".gd"):
			editor_interface.get_script_editor().open_script_create_dialog(file, str(start_line))
			# 延迟一帧再设置光标，确保编辑器加载完成
			await get_tree().process_frame
			var opened_editor = _get_current_code_edit()
			if opened_editor and _get_script_path(opened_editor) == file:
				opened_editor.set_caret_line(start_line)
				opened_editor.set_caret_column(0)
				opened_editor.center_viewport_to_caret()
		else:
			print("跳过非脚本文件: ", file)

	current_match_index = all_matches.find(match_data)
	if match_count_label and current_match_index != -1:
		match_count_label.text = _get_text("MATCH_COUNT").format({"current": current_match_index+1, "total": all_matches.size()})

func _on_result_tree_item_selected():
	var selected = result_tree.get_selected()
	if not selected: return
	var metadata = selected.get_metadata(0)
	if metadata is Dictionary:
		if metadata.has("type") and metadata.type == "file":
			selected.collapsed = not selected.collapsed
		elif metadata.has("start_line"):
			_jump_to_match_by_metadata(metadata)

# ---------- 编辑器工具函数 ----------
func _get_current_code_edit() -> CodeEdit:
	if not editor_interface: return null
	var se = editor_interface.get_script_editor()
	var current_editor = se.get_current_editor()
	if not is_instance_valid(current_editor):
		return null
	return _get_code_edit_from_script_editor(current_editor)

func _get_code_edit_from_script_editor(script_editor) -> CodeEdit:
	if not is_instance_valid(script_editor):
		return null
	if script_editor.has_method("get_text_edit"):
		return script_editor.get_text_edit()
	elif script_editor.has_method("get_base_editor"):
		return script_editor.get_base_editor()
	elif script_editor.has_method("get_code_edit"):
		return script_editor.get_code_edit()
	elif script_editor is Node:
		for child in script_editor.get_children():
			if child is CodeEdit:
				return child
	return null

func _get_script_path(editor: CodeEdit) -> String:
	var se = editor_interface.get_script_editor()
	for script_editor in se.get_open_scripts():
		if not is_instance_valid(script_editor):
			continue
		var code_edit = _get_code_edit_from_script_editor(script_editor)
		if code_edit == editor:
			return script_editor.get_script_path()
	return ""

func _get_script_name(editor: CodeEdit) -> String:
	var path = _get_script_path(editor)
	if not path.is_empty():
		return path.get_file()
	return "未知"

# ---------- 导入场景树 ----------
func _on_import_scene_pressed():
	var clipboard_text = DisplayServer.clipboard_get()
	if clipboard_text.is_empty():
		print("剪贴板为空")
		return

	var json = JSON.new()
	var error = json.parse(clipboard_text)
	if error == OK:
		var data = json.get_data()
		if typeof(data) == TYPE_DICTIONARY:
			_import_from_json(data)
			return

	var importers = _load_importers()
	for importer in importers:
		if importer.has_method("can_parse") and importer.has_method("parse"):
			if importer.can_parse(clipboard_text):
				var result = importer.parse(clipboard_text)
				if result is Dictionary:
					_import_from_json(result)
					return
				elif result is Node:
					_add_imported_node(result)
					return
				else:
					print("自定义导入器返回了无效类型: ", typeof(result))
		else:
			print("导入器脚本缺少 can_parse 或 parse 方法")

	_import_from_tscn_text(clipboard_text)

func _load_importers() -> Array:
	var importers = []
	var base_dir = "res://addons/code_search/importers/"
	var dir = DirAccess.open(base_dir)
	if not dir:
		return importers
	dir.list_dir_begin()
	var file = dir.get_next()
	while file != "":
		if file.ends_with(".gd"):
			var script_path = base_dir + file
			var script = load(script_path)
			if script and script is GDScript:
				importers.append(script)
		file = dir.get_next()
	return importers

func _add_imported_node(root_node: Node):
	var scene_root = editor_interface.get_edited_scene_root()
	if scene_root == null:
		var path_info = _get_safe_scene_path(root_node.name)
		var scene_path = path_info.path
		var file_exists = path_info.exists

		if file_exists:
			var confirm_dialog = ConfirmationDialog.new()
			confirm_dialog.dialog_text = _get_text("CONFIRM_OVERWRITE").format({"path": scene_path})
			confirm_dialog.ok_button_text = _get_text("CONFIRM")
			confirm_dialog.cancel_button_text = _get_text("CANCEL")
			add_child(confirm_dialog)
			confirm_dialog.popup_centered()
			var overwrite = await confirm_dialog.confirmed
			confirm_dialog.queue_free()
			if not overwrite:
				return

		var packed_scene = PackedScene.new()
		packed_scene.pack(root_node)
		var err = ResourceSaver.save(packed_scene, scene_path)
		if err != OK:
			var err_dialog = AcceptDialog.new()
			err_dialog.dialog_text = _get_text("ERR_SAVE_SCENE").format({"path": scene_path})
			err_dialog.title = _get_text("IMPORT_ERROR")
			add_child(err_dialog)
			err_dialog.popup_centered()
			await err_dialog.confirmed
			err_dialog.queue_free()
			return

		editor_interface.open_scene_from_path(scene_path)
		var info_dialog = AcceptDialog.new()
		info_dialog.dialog_text = _get_text("INFO_NEW_SCENE").format({"path": scene_path})
		info_dialog.title = _get_text("IMPORT_SUCCESS")
		add_child(info_dialog)
		info_dialog.popup_centered()
		await info_dialog.confirmed
		info_dialog.queue_free()
	else:
		scene_root.add_child(root_node)
		root_node.owner = scene_root
		var info_dialog = AcceptDialog.new()
		info_dialog.dialog_text = _get_text("INFO_IMPORT_SUCCESS")
		info_dialog.title = _get_text("IMPORT_SUCCESS")
		add_child(info_dialog)
		info_dialog.popup_centered()
		await info_dialog.confirmed
		info_dialog.queue_free()

func _import_from_json(data: Dictionary):
	var scene_root = editor_interface.get_edited_scene_root()
	if scene_root == null:
		var created_nodes = _create_nodes_from_data(data, null)
		if created_nodes.is_empty():
			print("未创建任何节点")
			return

		var root_node = null
		for node in created_nodes:
			if node.get_parent() == null:
				root_node = node
				break

		if root_node == null:
			print("没有找到根节点")
			return

		var path_info = _get_safe_scene_path(root_node.name)
		var scene_path = path_info.path
		var file_exists = path_info.exists

		if file_exists:
			var confirm_dialog = ConfirmationDialog.new()
			confirm_dialog.dialog_text = _get_text("CONFIRM_OVERWRITE").format({"path": scene_path})
			confirm_dialog.ok_button_text = _get_text("CONFIRM")
			confirm_dialog.cancel_button_text = _get_text("CANCEL")
			add_child(confirm_dialog)
			confirm_dialog.popup_centered()
			var overwrite = await confirm_dialog.confirmed
			confirm_dialog.queue_free()
			if not overwrite:
				return

		var packed_scene = PackedScene.new()
		packed_scene.pack(root_node)
		var err = ResourceSaver.save(packed_scene, scene_path)
		if err != OK:
			var err_dialog = AcceptDialog.new()
			err_dialog.dialog_text = _get_text("ERR_SAVE_SCENE").format({"path": scene_path})
			err_dialog.title = _get_text("IMPORT_ERROR")
			add_child(err_dialog)
			err_dialog.popup_centered()
			await err_dialog.confirmed
			err_dialog.queue_free()
			return

		editor_interface.open_scene_from_path(scene_path)
		var info_dialog = AcceptDialog.new()
		info_dialog.dialog_text = _get_text("INFO_NEW_SCENE").format({"path": scene_path})
		info_dialog.title = _get_text("IMPORT_SUCCESS")
		add_child(info_dialog)
		info_dialog.popup_centered()
		await info_dialog.confirmed
		info_dialog.queue_free()
	else:
		var created_nodes = _create_nodes_from_data(data, scene_root)
		if created_nodes.is_empty():
			print("未创建任何节点")
		else:
			print("成功创建 %d 个节点" % created_nodes.size())
			var info_dialog = AcceptDialog.new()
			info_dialog.dialog_text = _get_text("INFO_IMPORT_SUCCESS")
			info_dialog.title = _get_text("IMPORT_SUCCESS")
			add_child(info_dialog)
			info_dialog.popup_centered()
			await info_dialog.confirmed
			info_dialog.queue_free()

func _import_from_tscn_text(text: String):
	var trimmed = text.strip_edges()
	if not (trimmed.begins_with("[gd_scene") or trimmed.begins_with("[scene-gd")):
		var err_dialog = AcceptDialog.new()
		err_dialog.dialog_text = _get_text("ERR_NOT_VALID_TSCN")
		err_dialog.title = _get_text("IMPORT_ERROR")
		add_child(err_dialog)
		err_dialog.popup_centered()
		await err_dialog.confirmed
		err_dialog.queue_free()
		return

	var temp_dir = OS.get_cache_dir() + "/godot_temp/"
	var mkdir_err = DirAccess.make_dir_recursive_absolute(temp_dir)
	if mkdir_err != OK:
		print("无法创建临时目录: ", temp_dir)
		return
	var temp_file_path = temp_dir + "temp_import.tscn"
	var file = FileAccess.open(temp_file_path, FileAccess.WRITE)
	if not file:
		print("无法创建临时文件")
		return
	file.store_string(text)
	file.close()

	var scene = ResourceLoader.load(temp_file_path, "PackedScene", ResourceLoader.CACHE_MODE_IGNORE)
	if scene == null:
		var err_dialog = AcceptDialog.new()
		err_dialog.dialog_text = _get_text("ERR_LOAD_TSCN")
		err_dialog.title = _get_text("IMPORT_ERROR")
		add_child(err_dialog)
		err_dialog.popup_centered()
		await err_dialog.confirmed
		err_dialog.queue_free()
		return

	var instance = scene.instantiate()
	if instance == null:
		var err_dialog = AcceptDialog.new()
		err_dialog.dialog_text = _get_text("ERR_INSTANTIATE")
		err_dialog.title = _get_text("IMPORT_ERROR")
		add_child(err_dialog)
		err_dialog.popup_centered()
		await err_dialog.confirmed
		err_dialog.queue_free()
		return

	var scene_root = editor_interface.get_edited_scene_root()
	if scene_root == null:
		var new_scene_root = Node2D.new()
		new_scene_root.name = "Root"
		editor_interface.get_script_editor().open_script_create_dialog(new_scene_root.get_script(), "-1")
		editor_interface.set_main_screen_editor("2D")
		new_scene_root.add_child(instance)
		instance.owner = new_scene_root
		var info_dialog = AcceptDialog.new()
		info_dialog.dialog_text = _get_text("INFO_NEW_SCENE")
		info_dialog.title = _get_text("IMPORT_SUCCESS")
		add_child(info_dialog)
		info_dialog.popup_centered()
		await info_dialog.confirmed
		info_dialog.queue_free()
	else:
		scene_root.add_child(instance)
		instance.owner = scene_root
		var info_dialog = AcceptDialog.new()
		info_dialog.dialog_text = _get_text("INFO_IMPORT_SUCCESS")
		info_dialog.title = _get_text("IMPORT_SUCCESS")
		add_child(info_dialog)
		info_dialog.popup_centered()
		await info_dialog.confirmed
		info_dialog.queue_free()

	DirAccess.remove_absolute(temp_file_path)

func _create_nodes_from_data(data: Dictionary, parent: Node) -> Array[Node]:
	var created_nodes: Array[Node] = []
	if not data.has("type"):
		return created_nodes

	var node_type = data["type"]
	var node = ClassDB.instantiate(node_type)
	if node == null:
		print("无法实例化节点类型: ", node_type)
		return created_nodes

	var node_name = data.get("name", node_type)
	node.name = node_name

	if data.has("properties"):
		var props = data["properties"]
		for key in props:
			var value = props[key]
			var godot_value = _convert_to_godot_value(value)
			if key in node:
				node[key] = godot_value
			elif node.has_method("set_" + key):
				node.call("set_" + key, godot_value)
			else:
				print("节点 ", node_type, " 没有属性 ", key)

		if node_type == "OptionButton" and props.has("_items"):
			for item in props["_items"]:
				node.add_item(item)

	if parent:
		parent.add_child(node)
		node.owner = parent.owner if parent.owner else parent
	created_nodes.append(node)

	if data.has("children") and data["children"] is Array:
		for child_data in data["children"]:
			var child_nodes = _create_nodes_from_data(child_data, node)
			created_nodes.append_array(child_nodes)

	return created_nodes

func _convert_to_godot_value(value) -> Variant:
	match typeof(value):
		TYPE_DICTIONARY:
			if value.has("x") and value.has("y") and value.size() == 2:
				return Vector2(value["x"], value["y"])
			elif value.has("r") and value.has("g") and value.has("b"):
				return Color(value["r"], value["g"], value.get("a", 1.0))
			elif value.has("x") and value.has("y") and value.has("z"):
				return Vector3(value["x"], value["y"], value["z"])
			else:
				return value
		TYPE_ARRAY:
			return value
		_:
			return value

# ---------- 文件类型设置 ----------
func save_file_type_setting(index: int):
	if not editor_interface: return
	var settings = editor_interface.get_editor_settings()
	settings.set_setting("code_search/file_type", index)

func load_file_type_setting():
	if not editor_interface or not file_type_option: return
	var settings = editor_interface.get_editor_settings()
	if settings.has_setting("code_search/file_type"):
		file_type_option.selected = settings.get_setting("code_search/file_type")
	else:
		file_type_option.selected = 0

# ---------- 搜索历史 ----------
func load_search_history():
	if not editor_interface: return
	var settings = editor_interface.get_editor_settings()
	var raw_history = settings.get_setting("code_search/search_history")
	var history_items = []
	if typeof(raw_history) == TYPE_ARRAY:
		history_items = raw_history
	elif typeof(raw_history) == TYPE_PACKED_STRING_ARRAY:
		var old = raw_history as PackedStringArray
		history_items = []
		for s in old:
			history_items.append({ "text": s, "time": Time.get_unix_time_from_system() })
	else:
		history_items = []

	history_items.sort_custom(func(a,b): return a.time > b.time)

	var popup = history_btn.get_popup()
	popup.clear()
	if history_items.is_empty():
		popup.add_item(_get_text("EMPTY_HISTORY"), -1)
		popup.set_item_disabled(0, true)
	else:
		for i in range(min(history_items.size(), MAX_HISTORY)):
			var item = history_items[i]
			popup.add_item(item.text, i)

func add_to_history(text: String):
	if text.is_empty() or not editor_interface: return
	var settings = editor_interface.get_editor_settings()
	var history = settings.get_setting("code_search/search_history")
	if history == null:
		history = []

	var history_items = []
	if typeof(history) == TYPE_ARRAY:
		history_items = history
	elif typeof(history) == TYPE_PACKED_STRING_ARRAY:
		var old = history as PackedStringArray
		history_items = []
		for s in old:
			history_items.append({ "text": s, "time": Time.get_unix_time_from_system() })

	var found = false
	for i in range(history_items.size()):
		if history_items[i].text == text:
			history_items[i].time = Time.get_unix_time_from_system()
			found = true
			break
	if not found:
		history_items.append({ "text": text, "time": Time.get_unix_time_from_system() })

	history_items.sort_custom(func(a,b): return a.time > b.time)
	if history_items.size() > MAX_HISTORY:
		history_items.resize(MAX_HISTORY)

	settings.set_setting("code_search/search_history", history_items)

func clear_history():
	if not editor_interface: return
	var settings = editor_interface.get_editor_settings()
	settings.set_setting("code_search/search_history", [])
	load_search_history()

func _on_history_menu_about_to_popup():
	load_search_history()

func _on_history_item_selected(id: int):
	var popup = history_btn.get_popup()
	var text = popup.get_item_text(id)
	if text != _get_text("EMPTY_HISTORY"):
		search_edit.text = text
		_on_search_text_changed()

# ---------- 范围设置 ----------
func save_range_setting(index: int):
	if not editor_interface: return
	var settings = editor_interface.get_editor_settings()
	settings.set_setting("code_search/dock_range", index)

func load_range_setting() -> int:
	if not editor_interface: return 0
	var settings = editor_interface.get_editor_settings()
	if settings.has_setting("code_search/dock_range"):
		return settings.get_setting("code_search/dock_range")
	return 0

func load_ui_state():
	load_search_history()
	var range_idx = load_range_setting()
	range_option.selected = range_idx
	if file_type_option:
		load_file_type_setting()

# ---------- 替换功能 ----------
func _on_replace_all_pressed():
	var search_text = search_edit.text
	var replace_text = replace_edit.text
	if search_text.is_empty(): return
	var total_matches = all_matches.size()
	if total_matches == 0: return
	var range_name = [_get_text("RANGE_CURRENT"), _get_text("RANGE_OPEN"), _get_text("RANGE_PROJECT")][range_option.selected]
	confirm_dialog.dialog_text = _get_text("CONFIRM_REPLACE").format({"range": range_name, "count": total_matches})
	pending_replace_data = {
		"search_text": search_text,
		"replace_text": replace_text,
		"regex": regex_btn.button_pressed,
		"case_sensitive": case_sensitive_btn.button_pressed,
		"range": range_option.selected
	}
	confirm_dialog.popup_centered()

func _on_replace_confirmed():
	var data = pending_replace_data
	if data.is_empty(): return
	if data.has("batch_goto") and data.batch_goto:
		var matches = data.matches
		for match in matches:
			_jump_to_match_by_metadata(match)
			await get_tree().create_timer(0.1).timeout
		pending_replace_data.clear()
		return

	var search_text = data.search_text
	var replace_text = data.replace_text
	var use_regex = data.regex
	var case_sensitive = data.case_sensitive
	var range_type = data.range

	var pattern: String
	var case_flag = "" if case_sensitive else "(?i)"
	if use_regex:
		pattern = case_flag + search_text
	else:
		pattern = case_flag + _escape_regexp(search_text)

	var regex = RegEx.new()
	if regex.compile(pattern) != OK:
		print("正则表达式编译失败: ", pattern)
		return

	var se = editor_interface.get_script_editor()
	var editors_to_replace: Array[CodeEdit] = []
	var replaced_count = 0

	if range_type == 0:  # 当前文件
		var current = _get_current_code_edit()
		if current:
			editors_to_replace.append(current)
	elif range_type == 1:  # 所有打开文件
		for script_editor in se.get_open_scripts():
			if not is_instance_valid(script_editor):
				continue
			var code_edit = _get_code_edit_from_script_editor(script_editor)
			if code_edit:
				editors_to_replace.append(code_edit)
	else:  # 整个项目
		var extensions: PackedStringArray = []
		if file_type_option:
			match file_type_option.selected:
				0:
					extensions = [".gd"]
				1:
					extensions = [".gd", ".tscn", ".tres", ".json", ".txt", ".cfg"]
				2:
					extensions = [".gd", ".tscn", ".tres", ".json", ".txt", ".cfg", ".md", ".csv", ".xml", ".yaml"]
				_:
					extensions = [".gd"]
		else:
			extensions = [".gd"]
		var files = _get_files_by_extensions("res://", extensions)
		print("找到 %d 个文件待处理" % files.size())  # 调试
		for file in files:
			var content = FileAccess.get_file_as_string(file)
			if content == "":
				print("文件内容为空: ", file)
				continue
			var new_content = regex.sub(content, replace_text, true)
			if new_content != content:
				print("替换文件: ", file)   # 调试
				var f = FileAccess.open(file, FileAccess.WRITE)
				if f:
					f.store_string(new_content)
					f.close()
					replaced_count += 1
					# 更新已打开编辑器中的内容
					for script_editor in se.get_open_scripts():
						if not is_instance_valid(script_editor):
							continue
						var code_edit = _get_code_edit_from_script_editor(script_editor)
						if code_edit and _get_script_path(code_edit) == file:
							code_edit.text = new_content
							code_edit.queue_redraw()
							break
				else:
					print("无法写入文件: ", file)
		if replaced_count > 0:
			print("已替换 %d 个文件中的匹配项" % replaced_count)
		else:
			print("没有找到匹配项")
		# 清除缓存并重新搜索
		search_cache.clear()
		_search()
		add_to_history(search_text)
		return

	for editor in editors_to_replace:
		var full_text = editor.text
		var new_text = regex.sub(full_text, replace_text, true)
		if new_text != full_text:
			editor.text = new_text
			
# 在 dock_panel.gd 中添加此函数
func _get_safe_scene_path(root_node_name: String) -> Dictionary:
	var safe_name = root_node_name.replace(" ", "_").replace("/", "_").replace("\\", "_")
	var base_path = "res://"
	var scene_path = base_path + safe_name + ".tscn"
	var file_exists = ResourceLoader.exists(scene_path)
	return { "path": scene_path, "exists": file_exists }

	search_cache.clear()
	_search()
	add_to_history(search_edit.text)
