@tool
extends EditorPlugin

# 弹窗相关
var popup_window: Control
var is_popup_visible: bool = false

# 停靠面板
var dock_panel: Control

# 合并后的菜单按钮
var menu_button: MenuButton

# 快捷键
var popup_shortcut: Shortcut
var dock_shortcut: Shortcut

# 菜单项ID常量
const MENU_ITEM_POPUP = 0
const MENU_ITEM_DOCK = 1
const MENU_ITEM_SETTINGS = 2

# 语言菜单项ID起始
const LANG_MENU_START = 100

# 插件语言（默认中文）
var plugin_locale: String = "zh"

# 快捷键配置对话框相关
var shortcut_dialog: Window
var waiting_for_key: bool = false
var current_shortcut_type: String = ""  # "popup" 或 "dock"
var key_prompt_label: Label

# 翻译字典（内置，无需CSV）
var _translations: Dictionary = {
	"en": {
		"SEARCH_BUTTON": "Code Search",
		"POPUP_MENU": "Floating Popup",
		"DOCK_MENU": "Dock Panel",
		"LANGUAGE": "Language",
		"LANG_ENGLISH": "English",
		"LANG_CHINESE": "中文",
		"CONFIRM": "Confirm",
		"PREV": "Prev",
		"NEXT": "Next",
		"CLEAR": "Clear",
		"HISTORY": "History",
		"MATCH_COUNT": "{current}/{total}",
		"MATCH_COUNT_SIMPLE": "{total} matches",
		"EMPTY_HISTORY": "(empty)",
		"INVALID_REGEX": "Invalid regex",
		"REPLACE_WITH": "Replace with:",
		"REPLACE_ALL": "Replace All",
		"RANGE_CURRENT": "Current File",
		"RANGE_OPEN": "All Open Files",
		"RANGE_PROJECT": "Whole Project",
		"CONFIRM_REPLACE": "Replace {count} occurrence(s) in {range}?",
		"CANCEL": "Cancel",
		"GOTO_SELECTED": "Goto Selected",
		"COPY_LINE": "Copy Line Content",
		"COPY_PATH": "Copy File Path",
		"SHOW_IN_FOLDER": "Show in Folder",
		"BATCH_COPY_PATH": "Batch Copy Paths",
		"BATCH_GOTO": "Batch Goto",
		"BATCH_GOTO_CONFIRM": "Jump to {count} locations?",
		"EXPORT": "Export",
		"EXPORT_TITLE": "Export Search Results",
		"FILE_TYPE_LABEL": "File Type:",
		"FILE_TYPE_GD_ONLY": "Godot Scripts (.gd)",
		"FILE_TYPE_INCLUDE_RESOURCES": "Include Resources (.tscn, .tres, .json)",
		"FILE_TYPE_ALL_TEXT": "All Text Files",
		"PREVIEW": "Preview",
		"PREVIEW_TITLE": "Code Preview",
		"PREVIEW_ERROR": "Unable to read file content.",
		"SEARCHING": "Searching...",
		"SETTINGS": "Settings",
		"SET_POPUP_SHORTCUT": "Set Popup Shortcut (Ctrl+Shift+?)",
		"SET_DOCK_SHORTCUT": "Set Dock Shortcut (Ctrl+Shift+?)",
		"PRESS_A_KEY": "Press a key...",
		"CURRENT_SHORTCUT": "Current shortcut: Ctrl+Shift+{key}",
		"SHORTCUT_SET": "Shortcut set to Ctrl+Shift+{key}",
		"IMPORT_SCENE": "Import Scene Tree",
		"IMPORT_ERROR": "Import Error",
		"IMPORT_SUCCESS": "Import Success",
		"ERR_NOT_VALID_TSCN": "Clipboard content is not a valid Godot scene file (must start with '[gd_scene' or '[scene-gd').",
		"ERR_LOAD_TSCN": "Failed to load scene from clipboard.",
		"ERR_INSTANTIATE": "Failed to instantiate scene.",
		"INFO_NEW_SCENE": "New scene created and saved to {path}. It is now open.",
		"INFO_IMPORT_SUCCESS": "Scene tree imported successfully.",
		"ERR_SAVE_SCENE": "Failed to save scene to {path}.",
		"ERR_NO_SCENE": "No scene is open. Please open or create a scene first.",
		"CONFIRM_OVERWRITE": "File {path} already exists. Overwrite?",
		"ERR_INVALID_SCRIPT": "Clipboard content is not a valid GDScript.",
		"ERR_SAVE_SCRIPT": "Failed to save script to {path}.",
		"ERR_LOAD_SCRIPT": "Failed to load the script after saving.",
		"INFO_SCRIPT_ATTACHED": "Script attached to node '{node}'.",
		"IMPORT_SCRIPT": "Import Script",
		"INFO_SCRIPT_SAVED": "Script saved to {path} and opened in editor."
	},
	"zh": {
		"SEARCH_BUTTON": "代码搜索",
		"POPUP_MENU": "浮动弹窗",
		"DOCK_MENU": "停靠面板",
		"LANGUAGE": "语言",
		"LANG_ENGLISH": "English",
		"LANG_CHINESE": "中文",
		"CONFIRM": "确认",
		"PREV": "上一个",
		"NEXT": "下一个",
		"CLEAR": "清空",
		"HISTORY": "历史",
		"MATCH_COUNT": "{current}/{total}",
		"MATCH_COUNT_SIMPLE": "{total}个匹配",
		"EMPTY_HISTORY": "(空)",
		"INVALID_REGEX": "无效正则",
		"REPLACE_WITH": "替换为：",
		"REPLACE_ALL": "全部替换",
		"RANGE_CURRENT": "当前文件",
		"RANGE_OPEN": "所有打开文件",
		"RANGE_PROJECT": "整个项目",
		"CONFIRM_REPLACE": "确定在{range}中替换{count}处？",
		"CANCEL": "取消",
		"GOTO_SELECTED": "跳转到所选",
		"COPY_LINE": "复制行内容",
		"COPY_PATH": "复制文件路径",
		"SHOW_IN_FOLDER": "在文件夹中显示",
		"BATCH_COPY_PATH": "批量复制路径",
		"BATCH_GOTO": "批量跳转",
		"BATCH_GOTO_CONFIRM": "跳转到 {count} 个位置？",
		"EXPORT": "导出",
		"EXPORT_TITLE": "导出搜索结果",
		"FILE_TYPE_LABEL": "文件类型：",
		"FILE_TYPE_GD_ONLY": "Godot脚本 (.gd)",
		"FILE_TYPE_INCLUDE_RESOURCES": "包含资源文件 (.tscn, .tres, .json)",
		"FILE_TYPE_ALL_TEXT": "所有文本文件",
		"PREVIEW": "预览",
		"PREVIEW_TITLE": "代码预览",
		"PREVIEW_ERROR": "无法读取文件内容。",
		"SEARCHING": "搜索中...",
		"SETTINGS": "设置",
		"SET_POPUP_SHORTCUT": "设置弹窗快捷键 (Ctrl+Shift+?)",
		"SET_DOCK_SHORTCUT": "设置面板快捷键 (Ctrl+Shift+?)",
		"PRESS_A_KEY": "按下任意字母键...",
		"CURRENT_SHORTCUT": "当前快捷键: Ctrl+Shift+{key}",
		"SHORTCUT_SET": "快捷键已设置为 Ctrl+Shift+{key}",
		"IMPORT_SCENE": "导入场景树",
		"IMPORT_ERROR": "导入错误",
		"IMPORT_SUCCESS": "导入成功",
		"ERR_NOT_VALID_TSCN": "剪贴板内容不是有效的 Godot 场景文件（必须以 '[gd_scene' 或 '[scene-gd' 开头）。",
		"ERR_LOAD_TSCN": "无法从剪贴板加载场景。",
		"ERR_INSTANTIATE": "场景实例化失败。",
		"INFO_NEW_SCENE": "已创建新场景并保存到 {path}，现在已打开。",
		"INFO_IMPORT_SUCCESS": "场景树导入成功。",
		"ERR_SAVE_SCENE": "无法保存场景到 {path}。",
		"ERR_NO_SCENE": "未打开场景。请先打开或创建一个场景。",
		"CONFIRM_OVERWRITE": "文件 {path} 已存在，是否覆盖？",
		"ERR_INVALID_SCRIPT": "剪贴板内容不是有效的 GDScript。",
		"ERR_SAVE_SCRIPT": "无法保存脚本到 {path}。",
		"ERR_LOAD_SCRIPT": "保存后无法加载脚本。",
		"INFO_SCRIPT_ATTACHED": "脚本已附加到节点 '{node}'。",
		"IMPORT_SCRIPT": "导入脚本",
		"INFO_SCRIPT_SAVED": "脚本已保存到 {path} 并在编辑器中打开。"
	}
}

func _get_text(key: String) -> String:
	var lang_dict = _translations.get(plugin_locale, _translations["en"])
	return lang_dict.get(key, key)

func _enter_tree():
	load_language_setting()

	menu_button = MenuButton.new()
	menu_button.text = _get_text("SEARCH_BUTTON")
	var popup = menu_button.get_popup()
	popup.add_item(_get_text("POPUP_MENU"), MENU_ITEM_POPUP)
	popup.add_item(_get_text("DOCK_MENU"), MENU_ITEM_DOCK)
	popup.add_separator()
	popup.add_item(_get_text("SETTINGS"), MENU_ITEM_SETTINGS)
	popup.id_pressed.connect(_on_menu_item_pressed)
	add_control_to_container(CONTAINER_TOOLBAR, menu_button)

	popup_window = preload("res://addons/code_search/popup.tscn").instantiate()
	popup_window.editor_interface = get_editor_interface()
	popup_window.plugin_ref = self
	get_editor_interface().get_base_control().add_child(popup_window)
	popup_window.hide()
	popup_window.popup_closed.connect(_on_popup_closed)

	load_popup_position()

	dock_panel = preload("res://addons/code_search/dock_panel.tscn").instantiate()
	dock_panel.name = "代码面板"
	dock_panel.editor_interface = get_editor_interface()
	dock_panel.plugin_ref = self
	add_control_to_dock(EditorPlugin.DOCK_SLOT_LEFT_BR, dock_panel)
	dock_panel.hide()

	load_dock_state()
	_setup_language_menu()
	_update_dock_menu_check()
	_setup_shortcuts()

func _exit_tree():
	if menu_button:
		remove_control_from_container(CONTAINER_TOOLBAR, menu_button)
		menu_button.queue_free()
	if popup_window:
		popup_window.queue_free()
	if dock_panel:
		remove_control_from_docks(dock_panel)
		dock_panel.queue_free()
	if shortcut_dialog and is_instance_valid(shortcut_dialog):
		shortcut_dialog.queue_free()

func _setup_shortcuts():
	var settings = get_editor_interface().get_editor_settings()
	var popup_key = settings.get_setting("code_search/popup_shortcut_key")
	if popup_key == null:
		popup_key = KEY_F
	var dock_key = settings.get_setting("code_search/dock_shortcut_key")
	if dock_key == null:
		dock_key = KEY_D

	popup_shortcut = Shortcut.new()
	var event1 = InputEventKey.new()
	event1.ctrl_pressed = true
	event1.shift_pressed = true
	event1.keycode = popup_key
	popup_shortcut.events = [event1]

	dock_shortcut = Shortcut.new()
	var event2 = InputEventKey.new()
	event2.ctrl_pressed = true
	event2.shift_pressed = true
	event2.keycode = dock_key
	dock_shortcut.events = [event2]

func _shortcut_input(event: InputEvent):
	if popup_shortcut and popup_shortcut.matches_event(event) and event.is_pressed():
		_toggle_popup()
		get_viewport().set_input_as_handled()
	elif dock_shortcut and dock_shortcut.matches_event(event) and event.is_pressed():
		_toggle_dock()
		get_viewport().set_input_as_handled()

func _input(event: InputEvent):
	if waiting_for_key and event is InputEventKey and event.pressed and not event.echo:
		if shortcut_dialog and shortcut_dialog.visible:
			var keycode = event.keycode
			if keycode >= KEY_A and keycode <= KEY_Z:
				waiting_for_key = false
				var settings = get_editor_interface().get_editor_settings()
				if current_shortcut_type == "popup":
					settings.set_setting("code_search/popup_shortcut_key", keycode)
				elif current_shortcut_type == "dock":
					settings.set_setting("code_search/dock_shortcut_key", keycode)
				_setup_shortcuts()
				if shortcut_dialog and key_prompt_label:
					key_prompt_label.text = _get_text("SHORTCUT_SET").format({"key": char(keycode)})
					await get_tree().create_timer(1.5).timeout
					shortcut_dialog.hide()
					shortcut_dialog.queue_free()
					shortcut_dialog = null
			else:
				if shortcut_dialog and key_prompt_label:
					key_prompt_label.text = _get_text("PRESS_A_KEY") + " (A-Z only)"
					await get_tree().create_timer(1.0).timeout
					if key_prompt_label:
						key_prompt_label.text = _get_text("PRESS_A_KEY")
			get_viewport().set_input_as_handled()

func _on_menu_item_pressed(id: int):
	match id:
		MENU_ITEM_POPUP:
			_toggle_popup()
		MENU_ITEM_DOCK:
			_toggle_dock()
		MENU_ITEM_SETTINGS:
			_show_shortcut_dialog()
		_:
			if id >= LANG_MENU_START:
				var new_locale = "en" if id == LANG_MENU_START else "zh"
				set_language(new_locale)

# ---------- 快捷键配置对话框 ----------
# 在 _show_shortcut_dialog 函数中，用 LineEdit 替代按键捕获
func _show_shortcut_dialog():
	shortcut_dialog = Window.new()
	shortcut_dialog.title = _get_text("SETTINGS")
	shortcut_dialog.size = Vector2(400, 200)
	shortcut_dialog.exclusive = true
	shortcut_dialog.transient = true
	shortcut_dialog.visible = true
	add_child(shortcut_dialog)

	var vbox = VBoxContainer.new()
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vbox.size_flags_vertical = Control.SIZE_EXPAND_FILL
	shortcut_dialog.add_child(vbox)

	var settings = get_editor_interface().get_editor_settings()
	var popup_key = settings.get_setting("code_search/popup_shortcut_key")
	if popup_key == null: popup_key = KEY_F
	var dock_key = settings.get_setting("code_search/dock_shortcut_key")
	if dock_key == null: dock_key = KEY_D

	var popup_label = Label.new()
	popup_label.text = _get_text("CURRENT_SHORTCUT").format({"key": char(popup_key)})
	vbox.add_child(popup_label)

	var dock_label = Label.new()
	dock_label.text = _get_text("CURRENT_SHORTCUT").format({"key": char(dock_key)})
	vbox.add_child(dock_label)

	vbox.add_child(HSeparator.new())

	# 弹窗快捷键设置行
	var popup_row = HBoxContainer.new()
	vbox.add_child(popup_row)
	var popup_input = LineEdit.new()
	popup_input.placeholder_text = _get_text("ENTER_KEY")
	popup_input.max_length = 1
	popup_input.text = char(popup_key)
	popup_row.add_child(popup_input)
	var popup_btn = Button.new()
	popup_btn.text = _get_text("SET_POPUP_SHORTCUT")
	popup_btn.pressed.connect(func(): _set_shortcut(popup_input.text, "popup", popup_label))
	popup_row.add_child(popup_btn)

	# 面板快捷键设置行
	var dock_row = HBoxContainer.new()
	vbox.add_child(dock_row)
	var dock_input = LineEdit.new()
	dock_input.placeholder_text = _get_text("ENTER_KEY")
	dock_input.max_length = 1
	dock_input.text = char(dock_key)
	dock_row.add_child(dock_input)
	var dock_btn = Button.new()
	dock_btn.text = _get_text("SET_DOCK_SHORTCUT")
	dock_btn.pressed.connect(func(): _set_shortcut(dock_input.text, "dock", dock_label))
	dock_row.add_child(dock_btn)

	var close_btn = Button.new()
	close_btn.text = _get_text("CANCEL")
	close_btn.pressed.connect(func(): shortcut_dialog.hide(); shortcut_dialog.queue_free(); shortcut_dialog = null)
	vbox.add_child(close_btn)

	shortcut_dialog.grab_focus()

# 新增辅助函数 _set_shortcut
func _set_shortcut(input_text: String, shortcut_type: String, label: Label):
	var letter = input_text.strip_edges().to_upper()
	if letter.is_empty() or letter.length() > 1 or letter < "A" or letter > "Z":
		return
	var keycode = ord(letter)
	var settings = get_editor_interface().get_editor_settings()
	if shortcut_type == "popup":
		settings.set_setting("code_search/popup_shortcut_key", keycode)
	else:
		settings.set_setting("code_search/dock_shortcut_key", keycode)
	_setup_shortcuts()
	label.text = _get_text("SHORTCUT_SET").format({"key": letter})

func _on_set_popup_shortcut():
	waiting_for_key = true
	current_shortcut_type = "popup"
	if key_prompt_label:
		key_prompt_label.text = _get_text("PRESS_A_KEY")

func _on_set_dock_shortcut():
	waiting_for_key = true
	current_shortcut_type = "dock"
	if key_prompt_label:
		key_prompt_label.text = _get_text("PRESS_A_KEY")

# ---------- 原有函数 ----------
func _toggle_popup():
	if is_popup_visible:
		hide_popup()
	else:
		show_popup()

func show_popup():
	is_popup_visible = true
	if popup_window.has_method("reset_to_collapsed"):
		popup_window.reset_to_collapsed()
	popup_window.show()
	popup_window.move_to_front()

func hide_popup():
	is_popup_visible = false
	if popup_window.has_method("clear_highlight"):
		popup_window.clear_highlight()
	popup_window.hide()
	save_popup_position()

func _on_popup_closed():
	hide_popup()

func load_popup_position():
	var settings = get_editor_interface().get_editor_settings()
	if settings.has_setting("code_search/popup_position"):
		var pos = settings.get_setting("code_search/popup_position")
		popup_window.position = pos

func save_popup_position():
	var settings = get_editor_interface().get_editor_settings()
	settings.set_setting("code_search/popup_position", popup_window.position)

func _toggle_dock():
	dock_panel.visible = !dock_panel.visible
	save_dock_state()
	_update_dock_menu_check()

func _update_dock_menu_check():
	var popup = menu_button.get_popup()
	popup.set_item_checked(popup.get_item_index(MENU_ITEM_DOCK), dock_panel.visible)

func save_dock_state():
	var settings = get_editor_interface().get_editor_settings()
	settings.set_setting("code_search/dock_visible", dock_panel.visible)

func load_dock_state():
	var settings = get_editor_interface().get_editor_settings()
	if settings.has_setting("code_search/dock_visible"):
		dock_panel.visible = settings.get_setting("code_search/dock_visible")

# ---------- 独立翻译 ----------
func load_language_setting():
	var settings = get_editor_interface().get_editor_settings()
	if settings.has_setting("code_search/plugin_language"):
		plugin_locale = settings.get_setting("code_search/plugin_language")
	else:
		plugin_locale = "zh"

func save_language_setting():
	var settings = get_editor_interface().get_editor_settings()
	settings.set_setting("code_search/plugin_language", plugin_locale)

func set_language(locale: String):
	if locale == plugin_locale:
		return
	plugin_locale = locale
	save_language_setting()

	var popup = menu_button.get_popup()
	popup.set_item_text(popup.get_item_index(MENU_ITEM_POPUP), _get_text("POPUP_MENU"))
	popup.set_item_text(popup.get_item_index(MENU_ITEM_DOCK), _get_text("DOCK_MENU"))
	popup.set_item_text(popup.get_item_index(MENU_ITEM_SETTINGS), _get_text("SETTINGS"))
	var lang_en_index = popup.get_item_index(LANG_MENU_START)
	var lang_zh_index = popup.get_item_index(LANG_MENU_START + 1)
	if lang_en_index != -1:
		popup.set_item_text(lang_en_index, _get_text("LANG_ENGLISH"))
	if lang_zh_index != -1:
		popup.set_item_text(lang_zh_index, _get_text("LANG_CHINESE"))
	popup.set_item_checked(lang_en_index, locale == "en")
	popup.set_item_checked(lang_zh_index, locale == "zh")

	if dock_panel and dock_panel.has_method("refresh_ui"):
		dock_panel.call_deferred("refresh_ui")
	if popup_window and popup_window.has_method("refresh_ui"):
		popup_window.call_deferred("refresh_ui")

func _setup_language_menu():
	var popup = menu_button.get_popup()
	popup.add_separator()
	popup.add_item(_get_text("LANGUAGE"), -1, -1)
	popup.add_item(_get_text("LANG_ENGLISH"), LANG_MENU_START)
	popup.add_item(_get_text("LANG_CHINESE"), LANG_MENU_START + 1)
	popup.set_item_checked(popup.get_item_index(LANG_MENU_START), plugin_locale == "en")
	popup.set_item_checked(popup.get_item_index(LANG_MENU_START + 1), plugin_locale == "zh")

# 公共方法供弹窗和面板获取文本
func get_text(key: String) -> String:
	return _get_text(key)
