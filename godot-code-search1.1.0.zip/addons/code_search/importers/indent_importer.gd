# addons/code_search/importers/indent_importer.gd
extends Object

static func can_parse(text: String) -> bool:
	return text.contains("├─") or text.contains("└─") or text.contains("-")

static func parse(text: String):
	var lines = text.split("\n")
	var nodes = []
	var depths = []

	for line in lines:
		var trimmed = line.strip_edges()
		if trimmed == "":
			continue

		# 跳过注释行（以 # 开头）
		if trimmed.begins_with("#"):
			continue

		# 计算深度（支持树形符号和“-”）
		var depth = 0
		var i = 0
		var line_copy = line
		while i < line_copy.length():
			var ch = line_copy[i]
			if ch in [" ", "\t", "│", "├", "└", "─", "-"]:
				depth += 1
				i += 1
			else:
				break

		# 去除前导符号后提取内容
		var content = line_copy.substr(i).strip_edges()
		# 如果内容以“-”开头（例如“- ImageCo”），则去除前导“-”和空格
		if content.begins_with("-"):
			content = content.substr(1).strip_edges()

		var node_info = _parse_node_line(content)
		if node_info.is_empty():
			continue

		nodes.append(node_info)
		depths.append(depth)

	# 构建 JSON 树（与之前相同）
	var root_json = null
	var stack = []
	for idx in range(nodes.size()):
		var node_info = nodes[idx]
		var depth = depths[idx]
		var json_node = {
			"type": node_info["type"],
			"name": node_info.get("name", node_info["type"]),
			"properties": {},
			"children": []
		}

		var extra = node_info.get("extra", "")
		var node_text = node_info.get("text", "")
		if not node_text.is_empty():
			json_node["properties"]["text"] = node_text

		if node_info["type"] == "HSlider" and extra.contains("范围"):
			var regex = RegEx.new()
			regex.compile("(\\d+)-(\\d+)")
			var match = regex.search(extra)
			if match:
				json_node["properties"]["min_value"] = int(match.get_string(1))
				json_node["properties"]["max_value"] = int(match.get_string(2))
		elif node_info["type"] == "OptionButton" and extra.contains("选项:"):
			var parts = extra.split("选项:")
			if parts.size() >= 2:
				var options_str = parts[1].strip_edges()
				var items = options_str.split("/")
				json_node["properties"]["_items"] = items
		elif node_info["type"] == "CheckBox" and extra.contains("选中"):
			json_node["properties"]["button_pressed"] = true

		while stack.size() > 0 and stack[-1][1] >= depth:
			stack.pop_back()

		if stack.is_empty():
			root_json = json_node
		else:
			var parent = stack[-1][0]
			parent["children"].append(json_node)

		stack.append([json_node, depth])

	return root_json

# 以下 _parse_node_line 与之前相同（无修改）
static func _parse_node_line(line: String) -> Dictionary:
	var actual_type = ""
	var node_name = ""
	var extra = ""
	var node_text = ""

	# 先提取括号中的额外信息（如 (范围0-100)），排除类型括号
	var temp = line
	var extra_info = ""
	var paren_pos = line.find("(")
	if paren_pos != -1:
		var close_paren = line.find(")", paren_pos)
		if close_paren != -1:
			var inner = line.substr(paren_pos + 1, close_paren - paren_pos - 1).strip_edges()
			if ClassDB.class_exists(inner):
				# 保留括号，作为类型括号处理
				pass
			else:
				extra_info = inner
				temp = line.substr(0, paren_pos) + line.substr(close_paren + 1)
				temp = temp.strip_edges()
				var after = line.substr(close_paren + 1).strip_edges()
				if after != "":
					extra_info += " " + after
		else:
			# 括号不匹配，忽略
			pass

	var cleaned = temp
	extra = extra_info

	# 处理 "名称 (实际类型)" 格式
	paren_pos = cleaned.find("(")
	if paren_pos != -1:
		var close_paren = cleaned.find(")", paren_pos)
		if close_paren != -1:
			var inner = cleaned.substr(paren_pos + 1, close_paren - paren_pos - 1).strip_edges()
			if ClassDB.class_exists(inner):
				actual_type = inner
				node_name = cleaned.substr(0, paren_pos).strip_edges()
				var after = cleaned.substr(close_paren + 1).strip_edges()
				if after != "":
					extra = after + " " + extra
			else:
				actual_type = cleaned.substr(0, paren_pos).strip_edges()
				node_name = inner
				var after = cleaned.substr(close_paren + 1).strip_edges()
				if after != "":
					extra = after + " " + extra
		else:
			# 括号不匹配，忽略
			pass

	if actual_type == "":
		# 尝试 "类型: 名称" 格式
		var colon_pos = cleaned.find(":")
		if colon_pos != -1:
			actual_type = cleaned.substr(0, colon_pos).strip_edges()
			var rest = cleaned.substr(colon_pos + 1).strip_edges()
			var paren_pos2 = rest.find("(")
			if paren_pos2 != -1:
				var close_paren2 = rest.find(")", paren_pos2)
				if close_paren2 != -1:
					node_name = rest.substr(0, paren_pos2).strip_edges()
					extra = rest.substr(paren_pos2 + 1, close_paren2 - paren_pos2 - 1).strip_edges()
					var after = rest.substr(close_paren2 + 1).strip_edges()
					if after != "":
						extra += " " + after
				else:
					node_name = rest
			else:
				node_name = rest
			if node_name.begins_with("\"") and node_name.ends_with("\""):
				node_name = node_name.substr(1, node_name.length() - 2)
			node_text = node_name
		else:
			# 尝试 "类型 名称"
			var space_pos = cleaned.find(" ")
			if space_pos != -1:
				actual_type = cleaned.substr(0, space_pos).strip_edges()
				node_name = cleaned.substr(space_pos + 1).strip_edges()
				if node_name.begins_with("\"") and node_name.ends_with("\""):
					node_name = node_name.substr(1, node_name.length() - 2)
				node_text = node_name
			else:
				actual_type = cleaned
				node_name = actual_type

	if actual_type == "":
		return {}

	if node_name == "":
		node_name = actual_type

	return { "type": actual_type, "name": node_name, "extra": extra, "text": node_text }
